﻿using UnityEngine;
using System.Collections;

public class Conditionals : MonoBehaviour {


	// Use this for initialization
	void Start () {
		float score = 100f;
		Debug.Log(score >= 50f); // -> Turns into True or False

		if (score >= 95) {
			Debug.Log("You get a sticker - A+");	
		} else if (score >= 50f) {
			Debug.Log("You passed!");
		} else {
			Debug.Log("You failed :(");
		}

		Debug.Log("The grade is: " + GradeExam(100f));
		Debug.Log("The grade is: " + GradeExam(66f));
		Debug.Log("The grade is: " + GradeExam(20f));
		Debug.Log("The grade is: " + GradeExam(70f));
	}

	/*
		Create a grading function that takes a number and returns 
		the letter grade. You should be able to use it like this: 
			Debug.Log("The grade is: " + GradeExam(100f));
	*/
	string GradeExam(float score) {
		if (score >= 90) {
			return "A";
		} else if (score >= 80f) {
			return "B";
		} else if (score >= 70f) {
			return "C";
		} else if (score >= 60f) {
			return "D";
		} else {
			return "F";			
		}
	}

	// Update is called once per frame
	void Update () {
		// Debug.Log(Input.GetKey("a"));
		bool isSpaceKeyPressed = Input.GetKey("space");
		if (isSpaceKeyPressed) {
			Debug.Log("You found the secret button, you win.");
		}
	}
	
}
