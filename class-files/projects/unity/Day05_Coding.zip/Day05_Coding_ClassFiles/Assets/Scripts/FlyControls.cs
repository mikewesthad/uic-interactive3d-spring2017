﻿using UnityEngine;
using System.Collections;

public class FlyControls : MonoBehaviour {

	private float RotationX = 0f;
	private float RotationY = 0f;
	
	// Update is called once per frame
	void Update () {
		// Horizontal mouse movement (right is positive)
		Debug.Log("Mouse X Movement: " + Input.GetAxis("Mouse X"));
		// Vertical mouse movement (up is positive)
		Debug.Log("Mouse Y Movement: " + Input.GetAxis("Mouse Y"));

		// WARNING: DON'T REALLY DO THIS BAD BAD METHOD
		// float mouseX = Input.GetAxis("Mouse X");
		// transform.Rotate(0f, mouseX, 0f);
		// float mouseY = Input.GetAxis("Mouse Y");
		// transform.Rotate(-mouseY, 0f, 0f);

		// Using Quaternions
		RotationX = RotationX - Input.GetAxis("Mouse Y");
		RotationY = RotationY + Input.GetAxis("Mouse X");
		transform.localRotation = Quaternion.Euler(RotationX, RotationY, 0f);
		
	}
	
}
