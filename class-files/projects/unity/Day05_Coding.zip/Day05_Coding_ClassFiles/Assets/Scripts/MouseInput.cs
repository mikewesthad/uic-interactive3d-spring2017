﻿using UnityEngine;
using System.Collections;

public class MouseInput : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}


	void OnMouseEnter() {
		Debug.Log("Hi, mouse!");

		// Change the material's color to purple
		Material mat = GetComponent<MeshRenderer>().material;
		mat.color = new Color(1f, 0f, 1f, 1f);
	}

	void OnMouseExit() {
		// Change the material's color back to the default
		Material mat = GetComponent<MeshRenderer>().material;
		mat.color = new Color(1f, 1f, 1f, 1f);
	}

	void OnMouseOver() {
		float rotationSpeed = 360f; // Degrees per second
		transform.Rotate(0f, rotationSpeed * Time.deltaTime, 0f);
	}

	void OnMouseDown() {
		// Space.World means translate in the global coordinate system. By 
		// default, it will translate in the local coordinate system.
		transform.Translate(1f, 0f, 0f, Space.World);
	}

	// Update is called once per frame
	void Update () {
	
	}

}
