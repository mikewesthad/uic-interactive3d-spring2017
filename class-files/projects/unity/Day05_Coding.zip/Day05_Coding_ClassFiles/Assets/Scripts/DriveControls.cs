﻿using UnityEngine;
using System.Collections;

public class DriveControls : MonoBehaviour {

	// Fields - convention is to name these uppercase 
	public float Speed = 10f;
	public float TurnSpeed = 100f;
	
	void Update () {
		if (Input.GetKey("w")) {
			transform.Translate(0f, 0f, Speed * Time.deltaTime);
		} else if (Input.GetKey("s")) {
			transform.Translate(0f, 0f, -Speed * Time.deltaTime);
		}

		if (Input.GetKey("a")) {
			transform.Rotate(0f, -TurnSpeed * Time.deltaTime, 0f);
		} else if (Input.GetKey("d")) {
			transform.Rotate(0f, TurnSpeed * Time.deltaTime, 0f);
		}

		// Note: we used two separate if statements here, because we
		// want to be able to BOTH move forward and turn at the same
		// time.
	}
	
}
