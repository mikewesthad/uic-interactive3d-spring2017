﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChangeIntensity : MonoBehaviour {

	// Anything in Start runs ONCE when the scene starts
	void Start () {
		
		// "Light" is another variable type - except it's a custom variable
		// defined by Unity (a "class")
		Light light = GetComponent<Light>();
		// light.intensity: intensity is a variable "nested" inside of light
		light.intensity = 0f; // Turn off the light

	}
	
	// Update is run CONSTANTLY at 60 frames per second
	void Update () {

		Light light = GetComponent<Light>();
		light.intensity = light.intensity + 0.005f;
		
	}
}
