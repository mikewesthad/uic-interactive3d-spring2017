﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ManipulatingTransform : MonoBehaviour {

	// Use this for initialization
	void Start () {
		// transform.Translate(0f, 0f, 10f);
		// transform.Rotate(45f, 45f, 45f);
	}
	
	// Update is called once per frame
	void Update () {
		Debug.Log(Time.deltaTime);

		// (degrees per second) * (seconds passed in 1 frame) = (degrees per frame)
		float rotateSpeed = 45f; // Degrees per second
		transform.Rotate(rotateSpeed * Time.deltaTime, 0f, 0f);

		float moveSpeed = 2f; // Meters per second
		transform.Translate(0f, 0f, moveSpeed * Time.deltaTime);	
	}
}
