﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Variables : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
		// -- VARIABLES --------------------------------------------------------

		// Review
		Debug.Log("Hi again console");
		int numDays = 12;
		
		// Float (floating point decimals)
		float taxAmount = 0.07f;
		Debug.Log(taxAmount);
		// Errors:
		// float testScore = 89.5;

		// String (series of characters)
		string quoteOfTheDay = "Perfect is the enemy of good.";
		Debug.Log(quoteOfTheDay);
		string name;
		name = "Mike";


		// -- CONCATENATION ----------------------------------------------------

		int numJupiterMoons = 67;
		Debug.Log("Jupiter has " + numJupiterMoons + " moons.");

		// Beware the order of operations
		Debug.Log("Jupiter has " + (numJupiterMoons + 1) + " moons.");


		// -- MATH OPERATIONS --------------------------------------------------

		int total = 23 + 17 + 20;
		Debug.Log("The total is: " + total);

		int numPlanets = 9;
		numPlanets = numPlanets - 1; // Bye bye Pluto
		Debug.Log("Number of planets: " + numPlanets);
		numPlanets = numPlanets * 2; // Planets undergo mitosis
		Debug.Log("Number of planets: " + numPlanets);

		// Math works - but it depends on the data type 
		Debug.Log(6 / 3); // -> 2
		// Debug.Log(6 / "3"); // -> Error! Can't divide int by string
		Debug.Log(7 / 3); // -> 2, wtf? Integer math	
		Debug.Log(7 / 3f); // -> 2.33333, that's better


		// -- EXERCISES --------------------------------------------------------

		// 1) Find the total cost of three items
		// 		- magnets, $25.75
		//	 	- LEDs, $15.10
		// 		- tape, $3.10
		float totalCost = 25.75f + 15.10f + 3.10f;

		// 2) Print the total cost
		Debug.Log("The total cost is: " + totalCost);
		
		// 3) Now factor in a 25% discount and print the new total
		float discountedCost = totalCost * 0.75f;
		Debug.Log("The discounted cost is: " + discountedCost);

		// 4) Find the average of the following: 100, 90, 85, 74, 82
		float average = (100 + 90 + 85 + 74 + 82) / 5f;
		Debug.Log("The average is: " + average);

	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
