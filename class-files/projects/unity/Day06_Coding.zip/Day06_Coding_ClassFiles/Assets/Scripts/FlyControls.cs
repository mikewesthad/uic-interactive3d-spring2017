using UnityEngine;
using System.Collections;

public class FlyControls : MonoBehaviour {

	public float Speed = 3f;
	public float SensitivityX = 0.5f;
	public float SensitivityY = 0.5f;

	private float RotationX = 0F;
	private float RotationY = 0F;

	// Use this for initialization
	void Start () {
	}
	
	// Update is called once per frame
	void Update () {

		// Using quaternions
		RotationX += -Input.GetAxis("Mouse Y") * SensitivityY;
		RotationY += Input.GetAxis("Mouse X") * SensitivityX;
		transform.localRotation = Quaternion.Euler(RotationX, RotationY, 0f);

		// Shift boost
		float adjustedSpeed = Speed;
		if (Input.GetKey("left shift")) {
			adjustedSpeed = Speed * 2f;
		}

		// Moving forward/backward
		if (Input.GetKey("w")) {
			transform.Translate(0f, 0f, adjustedSpeed * Time.deltaTime);
		} else if (Input.GetKey("s")) {
			transform.Translate(0f, 0f, -adjustedSpeed * Time.deltaTime);
		}

		// Strafing
		if (Input.GetKey("a")) {
			transform.Translate(-adjustedSpeed * Time.deltaTime, 0f, 0f);
		} else if (Input.GetKey("d")) {
			transform.Translate(adjustedSpeed * Time.deltaTime, 0f, 0f);
		}

		// Up/down
		if (Input.GetKey("q")) {
			transform.Translate(0f, adjustedSpeed * Time.deltaTime, 0f);
		} else if (Input.GetKey("e")) {
			transform.Translate(0f, -adjustedSpeed * Time.deltaTime, 0f);
		}

		
	
	}
}
