﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TrackClicks : MonoBehaviour {

	private Material material;
	private int numClicks = 0;

	// Use this for initialization
	void Start () {
		material = GetComponent<MeshRenderer>().material;
		material.color = new Color(0f, 0f, 0f);
	}

	void OnMouseDown() {
		numClicks = numClicks + 1;
		Debug.Log("Number of clicks: " + numClicks);
		material.color = new Color(numClicks / 10f, 0f, 0f);
	}
}
