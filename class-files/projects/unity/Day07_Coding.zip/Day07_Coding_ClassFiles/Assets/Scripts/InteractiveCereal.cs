﻿using UnityEngine;
using System.Collections;

public class InteractiveCereal : MonoBehaviour {

	private Material material;

	// Use this for initialization
	void Start () {
		// transform gives us access to the Transform component
		
		// Can't do this :(((
		// transform.position.x = 10f;

		// Replacement method
		// transform.position = new Vector3(0f, 0f, 0f);

		// Modify method
		//	- Store a copy of the position from the transform
		// 	- Change the copy
		// 	- Put the copy back into the transform
		// Vector3 position = transform.position;
		// position.y = position.y + 6f;
		// transform.position = position;

		// Exercise: modify the localScale to be 5 in the x direction
		// Vector3 scale = transform.localScale;
		// scale.x = 5f;
		// transform.localScale = scale;

		material = GetComponent<MeshRenderer>().material;
	}
	
	void OnMouseEnter() {
		// Randomizing the position:
		// 	Random.Range(0f, 10f) -> Random number between 0 and 10
		float x = Random.Range(-3f, 3f);
		float y = Random.Range(3f, 7f);
		float z = Random.Range(-3f, 3f);
		transform.position = new Vector3(x, y, z);

		// Exercise: randomize the scale
		transform.localScale = new Vector3(
			Random.Range(0.25f, 3f),
			Random.Range(0.25f, 3f),
			Random.Range(0.25f, 3f)
		);

		// Exercise: randomize the material's color
		material.color = Random.ColorHSV(0f, 1f, 1f, 1f, 1f, 1f);

		// Random quaternion rotation
		transform.rotation = Random.rotationUniform;
	}
}
