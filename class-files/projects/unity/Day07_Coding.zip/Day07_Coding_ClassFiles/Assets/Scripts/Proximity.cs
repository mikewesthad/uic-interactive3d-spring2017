﻿using UnityEngine;
using System.Collections;

public class Proximity : MonoBehaviour {

	public Transform playerTransform;
	public float distanceTrigger = 4f;
	private Material material;
	private Color nearColor;
	private Vector3 initialScale;

	// Use this for initialization
	void Start () {
		material = GetComponent<MeshRenderer>().material;
		nearColor = Random.ColorHSV(0f, 1f, 1f, 1f, 1f, 1f);
		initialScale = transform.localScale;
	}

	// Update is called once per frame
	void Update () {
		// transform.position = position of the sphere
		// playerTransform.position = position of the player
		float distance = Vector3.Distance(transform.position,
			playerTransform.position);
		Debug.Log(distance);

		// If you are within the distance threshold, make the sphere one color
		// Otherwise, make it a different color.
		// Extension: when the player is far, make the color black. When the 
		// player is near, make the color a random color.
		if (distance <= distanceTrigger) {
			// How close we are to the target (as a num between 0 and 1)
			// 	0, when we are right at the target
			// 	1, when we are distanceTrigger away from the target
			float lerpAmount = distance / distanceTrigger;
			material.color = Color.Lerp(nearColor, Color.black, lerpAmount);

			// Vector3.Lerp the scale - triple in size as you get closer
			transform.localScale = Vector3.Lerp(
				initialScale * 3,
				initialScale,
				lerpAmount
			);

		} else {
			material.color = Color.black;
			transform.localScale = initialScale;
		}
	}
}
