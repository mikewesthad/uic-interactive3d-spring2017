﻿using UnityEngine;
using System.Collections;

public class RaycastDig : MonoBehaviour {
	
	public GameObject torch;
	public float digDistance = 3f;
	public float lightDistance = 2f;
	public float explodeDistance = 4f;
	private Camera camera;

	// Use this for initialization
	void Start () {
		camera = GetComponent<Camera>();	
	}
	
	// Update is called once per frame
	void Update () {
		Ray ray = camera.ScreenPointToRay(Input.mousePosition);

		// Drawing a ray - useful for debugging!
		Debug.DrawRay(ray.origin, ray.direction * 5f, Color.red, 1f);

		// Left click, dig a block in range
		if (Input.GetMouseButtonDown(0)) {
			RaycastHit hit;
			bool isHit = Physics.Raycast(ray, out hit, digDistance);
			if (isHit) {
				Destroy(hit.transform.gameObject);
			}
		// Right click, place torch if there is space
		} else if (Input.GetMouseButtonDown(1)) {
			if (!Physics.Raycast(ray, lightDistance)) {
				Instantiate(torch, ray.GetPoint(lightDistance), 
					Quaternion.identity);
			}
		// E, explode everything in range (except the player)
		} else if (Input.GetKeyDown(KeyCode.E)) {
			Collider[] colliders = Physics.OverlapSphere(transform.position, 
				explodeDistance);
			foreach (Collider collider in colliders) {
				if (collider.gameObject.tag != "Player") {
					Destroy(collider.gameObject);
				}
			}
		// Q, laser beam
		} else if (Input.GetKeyDown(KeyCode.Q)) {
			RaycastHit[] hits = Physics.SphereCastAll(ray, 0.3f);
			foreach (RaycastHit hit in hits) {
				if (hit.transform.tag != "Player") {
					Destroy(hit.transform.gameObject);
				}
			}
		}
	}

	// Debugging with Gizmos!
	void OnDrawGizmos() {
		if (camera == null) {
			// This runs even when we aren't in play mode, so to prevent errors,
			// check to make sure we have a camera.
			return;  
		}

		// Draw a series of spheres along the beam's path
		Gizmos.color = new Color(1, 0, 0, 0.5f);
		Ray ray = camera.ScreenPointToRay(Input.mousePosition);
		for (float i = 0; i < 20f; i += 0.3f) {
			Vector3 point = ray.GetPoint(i);
			Gizmos.DrawSphere(point, 0.3f);
		}

		// Draw a wireframe for the explosion's range
		Gizmos.color = new Color(1, 0, 1, 0.5f);
		Gizmos.DrawWireSphere(transform.position, explodeDistance);
	}
}
