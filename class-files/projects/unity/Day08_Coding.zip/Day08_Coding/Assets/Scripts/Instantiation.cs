﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Instantiation : MonoBehaviour {

	public GameObject cubePrefab;

	// Use this for initialization
	void Start () {
		Vector3 spawnPoint = new Vector3(0f, 2f, 0f);
		Quaternion rotation = Quaternion.Euler(45f, 45f, 0f);
		Instantiate(cubePrefab, spawnPoint, rotation);
	}

}
