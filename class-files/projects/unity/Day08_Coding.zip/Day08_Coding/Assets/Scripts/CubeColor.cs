﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CubeColor : MonoBehaviour {

	public Transform otherCube;
	private Material mat;

	// Use this for initialization
	void Start () {
		mat = GetComponent<MeshRenderer>().material;
	}
	
	// Update is called once per frame
	void Update () {

		float dist = Vector3.Distance(transform.position, otherCube.position);
		if (dist < 2f) {
			mat.color = Color.cyan;
		} else {
			mat.color = Color.black;
		}
		
	}
}
