﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LoopsPractice : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
		// i = i + 1  ->  i += 1
		for (int i = 10; i <= 100; i += 2) {
			Debug.Log("The current count is: " + i);
		}
		Debug.Log("Loop is over");

		// DANGER ZONE - INFINITE LOOP
		// for (int i = 0; i >= 0; i += 1) {
		// }

		// Summing the numbers between 0 and 10
		int sum = 0;
		for (int i = 0; i <= 10; i += 1) {
			sum += i;
		}
		Debug.Log("The sum is: " + sum);



		// Write a loop that prints the numbers from 5 to 15
		for (int i = 5; i <= 15; i++) {
			Debug.Log("The current count is: " + i);
		}

		// Write a loop that counts from 0 to 100, in incremements of 10
		for (int i = 0; i <= 100; i += 10) {
			Debug.Log("The current count is: " + i);
		}

		// Write a loop that counts down from 10 to 0
		for (int i = 10; i >= 0; i -= 1) {
			Debug.Log("The current count is: " + i);
		}

		// i++    ->    i += 1
		// i--    ->    i -= 1

	}
}
