﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PopcornLight : MonoBehaviour {

	private Rigidbody rigidbody;
	private Material material;
	private Light light;

	// Use this for initialization
	void Start () {
		rigidbody = GetComponent<Rigidbody>();
		material = GetComponent<Renderer>().material;
		light = GetComponent<Light>();

		// Demo: applying a force
		// Vector3 force = new Vector3(10f, 10f, 0f);
		// rigidbody.AddForce(force, ForceMode.Impulse); 	

		Invoke("Pop", Random.Range(1f, 3f));
	}

	void Pop() {
		// Random upward force
		Vector3 force = new Vector3(
			Random.Range(-10f, 10f), 
			Random.Range(15f, 30f), 
			Random.Range(-10f, 10f)
		);
		rigidbody.AddForce(force, ForceMode.Impulse);
		Invoke("Pop", Random.Range(1f, 3f));
	}

	void OnCollisionEnter(Collision collisionInfo) {
		// Debug.Log("Ouch!!");
		Color randomColor = Random.ColorHSV(0.4f, 0.8f, 1f, 1f, 1f, 1f);
		material.SetColor("_EmissionColor", randomColor);
		light.color = randomColor;
	}
}
