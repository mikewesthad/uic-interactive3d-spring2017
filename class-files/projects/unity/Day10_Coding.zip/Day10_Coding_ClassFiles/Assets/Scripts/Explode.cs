﻿using UnityEngine;
using System.Collections;

public class Explode : MonoBehaviour {

    public float ExplodeRange = 15f;

    void OnCollisionEnter(Collision collision) {
        if (collision.gameObject.tag != "Player") {
            ExplodeSphere();
        }
    }

    void ExplodeSphere() {
        // Get all colliders that are within range of the pokeball's transform
        Collider[] colliderArray = Physics.OverlapSphere(transform.position, ExplodeRange);

        foreach(Collider colliderElement in colliderArray) {
            Debug.Log(colliderElement);

            Rigidbody rb = colliderElement.attachedRigidbody;
            if (rb != null) {
                rb.AddExplosionForce(5000f, transform.position, ExplodeRange);
            }
        }

        // Exercise: when a pokemon is "exploded," change its color. A charred
        // black works.

        // gameObject = object the script is attached to
        Destroy(gameObject); // Destroy AFTER exploding
    }

    void OnDrawGizmos() {
        Gizmos.color = new Color(0, 0.5f, 1f, 0.5f);
        Gizmos.DrawSphere(transform.position, ExplodeRange);
        Gizmos.color = Color.black;
        Gizmos.DrawWireSphere(transform.position, ExplodeRange);
    }
    
}
