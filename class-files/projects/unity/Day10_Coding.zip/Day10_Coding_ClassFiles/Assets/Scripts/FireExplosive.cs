﻿using UnityEngine;
using System.Collections;

public class FireExplosive : MonoBehaviour {

	public GameObject pokeballPrefab;

	void Start () {
		
	}
	
	void Update () {
		if (Input.GetMouseButtonDown(0)) {
			GameObject pokeball = (GameObject) Instantiate(pokeballPrefab, 
				transform.position, transform.rotation);
			Rigidbody rb = pokeball.GetComponent<Rigidbody>();

			Vector3 force = new Vector3(0, 5f, 15f);
			rb.AddRelativeForce(force, ForceMode.Impulse);
			rb.AddRelativeTorque(new Vector3(-100f, 0, 0), ForceMode.Impulse);

			// Debug.Break();
		}
	}
}
