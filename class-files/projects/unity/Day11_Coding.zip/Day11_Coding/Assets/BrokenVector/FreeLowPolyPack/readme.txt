﻿Thank you for downloading our Free Low Poly Pack!
If you have any problems, please do not hesitate to mail us (support@brokenvector.net).


Please rate our product on the Unity Asset Store if you like it.


Broken Vector on Twitter: https://twitter.com/Broken_vector

Featured assets:
- Free Low Poly Pack: https://goo.gl/SsLsIG
- Low Poly Tree Pack: https://goo.gl/VKSJ0W
- Persistent Components: https://goo.gl/cfXq01

Also check out our other assets: https://goo.gl/UdEEHz