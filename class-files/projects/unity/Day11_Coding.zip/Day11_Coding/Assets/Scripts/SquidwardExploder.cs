﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
	
/*
	Warmup:

	1. Create a Squidward prefab from the squidward model. It needs:
		- a rigidbody
		- a convex collider
		- a "Squidward" tag
	2. Create a pile of squidwards in your scene.
	3. When the left mouse button is clicked. Create an explosion at (0, 0, 0)
	   and explode all the squidwards:
		- GameObject.FindGameObjectsWithTag(...) will let you search the 
		  scene for Squidwards. Check out the documentation page.
		- Rigidbody.AddExplosionForce(...) explodes stuff.
	4. (Bonus) Every 2 seconds, spawn in 20 new squidwards.	
*/

public class SquidwardExploder : MonoBehaviour {

	public GameObject squidwardPrefab;

	void Start() {
		SpawnSquidwards();
	}

	void SpawnSquidwards() {
		for (var i = 0; i < 20; i++) {
			Vector3 pos = new Vector3(
				Random.Range(-5f, 5f),
				5f,
				Random.Range(-5f, 5f)
			);
			GameObject newSquid = (GameObject) Instantiate(squidwardPrefab, pos,					Quaternion.identity);
			Rigidbody rb = newSquid.GetComponent<Rigidbody>();
			rb.AddRelativeTorque(new Vector3(0, 1000f, 0), ForceMode.Impulse);
		}
		Invoke("SpawnSquidwards", 2f);
	}

	void Update () {
		if (Input.GetMouseButtonDown(0)) {
			GameObject[] squids = GameObject.FindGameObjectsWithTag("Squidward");
			for (int i = 0; i < squids.Length; i++) {
				GameObject squid = squids[i];
				Rigidbody rb = squid.GetComponent<Rigidbody>();
				rb.AddExplosionForce(1500f, Vector3.zero, 10f);
			}
		}
	}

}
