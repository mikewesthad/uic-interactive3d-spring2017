﻿using UnityEngine;
using System.Collections;

// Exercise:
// 	- Instantiate a flower at the hit point (just pick your favorite of the 
// 	  models)
//  	- Look at the RaycastHit documentation to figure out how to do that
// 		- Give the flower a random (uniform) scale in order to add some variety
//  - Extension: instead of just using your favorite flower model, modify your 
//    code so that a random flower is planted
// 		- Remember how we spawned random Pokemon in the last scene?
//  - Extra bonus: what about animating the flowers so that they scale in from
//    0 when they are planted?
// 		- Hint: you can create flower prefabs that have a Grow.cs script 
// 		  attached. That script can then handle the animation.


public class SpawnRaycast : MonoBehaviour {

	public GameObject[] flowers;
	private Camera camera; 

	void Start () {
		camera = GetComponent<Camera>();
	}

	void Update () {
		if (Input.GetMouseButtonDown(0)) {
			// Get a ray from the camera into the world
			Ray ray = camera.ScreenPointToRay(Input.mousePosition);

			// Draw the ray so that we can see where it points.
			// We can do math on vectors:
			// (0, 0, 1) * 10 = (0, 0, 10)
			Debug.DrawRay(ray.origin, ray.direction * 10f, Color.red, 3f);

			RaycastHit hit;
			bool isHit = Physics.Raycast(ray, out hit, 2f);
			if (isHit) {
				Debug.Log("We just hit: " + hit.transform.name);
				Debug.Log("We hit at: " + hit.point);

				int index = Random.Range(0, flowers.Length);
				GameObject flowerPrefab = flowers[index];
				GameObject flower = (GameObject) Instantiate(flowerPrefab, 
					hit.point, Quaternion.identity);
				flower.transform.localScale = Vector3.one * Random.Range(10f, 15f);
			}
		}

	}

}