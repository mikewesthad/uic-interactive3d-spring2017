﻿using UnityEngine;
using System.Collections;

public class Explode : MonoBehaviour {

    public float ExplodeRange = 15f;

    void OnCollisionEnter(Collision collision) {
        if (collision.gameObject.tag != "Player") {
            ExplodeSphere();
        }
    }

    void ExplodeSphere() {
        // Get all colliders that are within range of the pokeball's transform
        Collider[] colliderArray = Physics.OverlapSphere(transform.position, ExplodeRange);

        foreach(Collider colliderElement in colliderArray) {
            Debug.Log(colliderElement);

            // Only do stuff to the pokemon
            if (colliderElement.gameObject.tag == "Pokemon") {
                Rigidbody rb = colliderElement.attachedRigidbody;
                rb.AddExplosionForce(5000f, transform.position, ExplodeRange);

                GameObject pokemon = colliderElement.gameObject;
                pokemon.GetComponent<MeshRenderer>().material.color = Color.black;
            }            
        }

        // gameObject = object the script is attached to
        Destroy(gameObject); // Destroy AFTER exploding
    }

	// Special Unity method for drawing debugging information
    void OnDrawGizmos() {
        Gizmos.color = new Color(0, 0.5f, 1f, 0.5f);
        Gizmos.DrawSphere(transform.position, ExplodeRange);
        Gizmos.color = Color.black;
        Gizmos.DrawWireSphere(transform.position, ExplodeRange);
    }
    
}
