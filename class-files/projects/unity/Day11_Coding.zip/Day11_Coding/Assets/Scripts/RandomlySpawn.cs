﻿using UnityEngine;
using System.Collections;

public class RandomlySpawn : MonoBehaviour {

	public GameObject[] pokemonPrefabs;
	public int numToSpawn = 100;

	void Start () {

		// Exercise: spawn a bunch of pokemon. Spawn them standing on the plane
		// at a random position, looking in a random direction.

		for (int i = 0; i < numToSpawn; i++) {
			
			// Picking a random pokemon prefab
			int randomIndex = Random.Range(0, pokemonPrefabs.Length);
			GameObject randomPokemon = pokemonPrefabs[randomIndex];

			// Picking a random location with a random rotation
			Vector3 randomPos = new Vector3(
				Random.Range(-20f, 20f),
				0f,
				Random.Range(-20f, 20f)
			);
			Quaternion randomRot = Quaternion.Euler(0, Random.Range(0f, 360f), 0);

			// Make dat pokemon
			Instantiate(randomPokemon, randomPos, randomRot);
			
		}

	}

}
