Toony Colors Free, version 2.0
2016/02/09
� 2016, Jean Moreno
==============================

PLEASE LEAVE A REVIEW OR RATE THE PACKAGE IF YOU FIND IT USEFUL!
Enjoy! :)

CONTACT
-------
Questions, suggestions, help needed?
Contact me at:
jean.moreno.public+unity@gmail.com

I'd be happy to see any shader used in your project, so feel free to drop me a line about that! :)


UPDATE NOTES
------------
v2.0
- new shaders based on Toony Colors Pro 2
- new demo scene

v1.41
- fixed alpha output for opaque shaders, could cause issues with RenderTextures

v1.4
- updated "JMO Assets" menu
- Unity 5 compatibility

v1.3
- changed name to "Toony Colors"

v1.2
- added JMO Assets menu (Window -> JMO Assets), to check for updates or get support

v1.1

- added Toony Gooch RimOutline Hard shader

- added 2 new toon ramp textures (3 tones lightning & soft shadow)

v1.0
- Initial Release