﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Instantiation : MonoBehaviour {

	public GameObject prefab;

	// Use this for initialization
	void Start () {	
		// Creating a copy of an object
		// Vector3 spawnPoint = new Vector3(0f, 2f, 0f);
		// Quaternion rotation = Quaternion.Euler(45f, 25f, 0f); // Or Quaternion.identity
		// Instantiate(prefab, spawnPoint, rotation);

		// Spawning and casting, so that we can manipulate
		// int num = (int) 1.5f;

		// Vector3 spawnPoint = new Vector3(1f, 0f, 0f);
		// Quaternion rotation = Quaternion.identity;
		// GameObject clone = (GameObject) Instantiate(prefab, spawnPoint, 
		// 	rotation, transform);
		// clone.name = "Super cool clone";
		// clone.transform.localScale = new Vector3(1f, Random.Range(1f, 3f), 1f); 
		// Material mat = clone.GetComponent<Renderer>().material;
		// mat.color = Random.ColorHSV(0.2f, 0.5f, 1, 1, 1, 1);

		// Looping and spawning a row
		// for (int i = 0; i <= 10; i += 1) {
		// 	Vector3 spawnPoint = new Vector3(i * 2f, 0f, 0f);
		// 	GameObject cube = (GameObject) Instantiate(prefab, spawnPoint, 
		// 		Quaternion.identity);
		// 	cube.name = "Clone " + i;

		// 	Material mat = cube.GetComponent<Renderer>().material;

		// 	// Challenge: add random color to the clones in the loop
		// 	// mat.color = Random.ColorHSV(0.2f, 0.5f, 1, 1, 1, 1);

		// 	// Challenge: create a row that forms a rainbow of colors
		// 	mat.color = Color.HSVToRGB(i / 10f, 1f, 1f);
		// }

		// Grid - 2D loop
		for (int x = 0; x < 10; x += 1) {
			for (int y = 0; y < 10; y += 1) {
				Vector3 spawnPoint = new Vector3(x * 1.5f, y * 1.5f, 0f);
				GameObject clone = (GameObject) Instantiate(prefab, spawnPoint, 
					Quaternion.identity);

				// Challenge: create a grid where hue changes along the x-axis
				// and value changes along the y-axis. Bonus, change the
				// rotation as well.
				Material mat = clone.GetComponent<Renderer>().material;
				mat.color = Color.HSVToRGB(x / 10f, 1f, y / 10f);
				
				Quaternion rotation = Quaternion.Euler(x * 10, 0f, y * 10);
				clone.transform.rotation = rotation;

			}
		}
	}

}
