﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Blinking : MonoBehaviour {

	private Light light;

	// Use this for initialization
	void Start () {
		light = GetComponent<Light>();
		light.enabled = false;
		Invoke("ToggleLight", Random.Range(0.05f, 0.1f));
	}

	void ToggleLight() {
		if (light.enabled) {
			light.enabled = false;
		} else {
			light.enabled = true;
		}
		// Advanced approach: light.enabled = !light.enabled;
		Invoke("ToggleLight", Random.Range(0.05f, 0.1f));
	}
	
}
