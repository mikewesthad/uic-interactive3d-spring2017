﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Arrays : MonoBehaviour {

	// Array 1: private highScores that we fill with data in Start
	private int[] highScores;

	// Array 2: public items that we fill in using the inspector
	public string[] items;

	// Array 3: array with initial data
	// Average hours of sunshine per month, data from: 
	// 	http://www.holiday-weather.com/chicago/averages/
	private int[] monthlySunshine = {3, 3, 6, 7, 9, 10, 12, 11, 9, 7, 6, 3};
	public GameObject simpleCube;

	// Use this for initialization
	void Start () {

		// Array 1:
		// Arrays are a fixed size
		highScores = new int[4];
		// Set the values in the array
		highScores[0] = 12;
		highScores[1] = 15;
		highScores[2] = 11;
		highScores[3] = 8;
		// Get the values from an array
		Debug.Log("The first high score is " + highScores[0]);
		Debug.Log("The last high score is " + highScores[3]);
		// Get the number of elements in the array
		Debug.Log("There are " + highScores.Length + " high scores saved.");

		// Array 2:
		for (int i = 0; i < items.Length; i += 1) {
			Debug.Log("The player has a(n) " + items[i]);
		}
		// Alternate loop: foreach
		foreach (string item in items) {
			Debug.Log("The player has a(n) " + item);
		}
		foreach (int score in highScores) {
			Debug.Log("The score is " + score);
		}


		// Array 3:
		// Loop through the array and create an instance of the SimpleCube model
		// for each month. Manipulate each cube so that:
		//  - Its height (e.g. y-scale) reflects the hours of sunshine in that 
		//    month
		//  - Its color reflects the hours of sunshine in that month (e.g. from
		//    black to yellow)
		float xPosition = 0;
		foreach (int sunshineHours in monthlySunshine) {
			Vector3 spawnPoint = new Vector3(xPosition, 0f, 0f);
			GameObject bar = (GameObject) Instantiate(simpleCube, spawnPoint, 
				Quaternion.identity);
			
			// Mapping the data to the y-scale
			bar.transform.localScale = new Vector3(1f, sunshineHours, 1f);

			// Mapping the data to the color
			Material mat = bar.GetComponent<Renderer>().material;
			mat.color = new Color(sunshineHours / 12f, sunshineHours / 12f, 0f);

			xPosition += 1.5f;
		}

	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
