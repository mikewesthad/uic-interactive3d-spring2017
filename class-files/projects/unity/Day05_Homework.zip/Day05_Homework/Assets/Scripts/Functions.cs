﻿using UnityEngine;
using System.Collections;

public class Functions : MonoBehaviour {

	void Start () {
		Debug.Log("32 F to C: " + ConvertFahrenheitToCelsius(32));
		Debug.Log("100 F to C: " + ConvertFahrenheitToCelsius(100));
	}
	
	float ConvertFahrenheitToCelsius(float fahrenheit) {
		float celsius = (fahrenheit - 32f) * 5f / 9f;
		return celsius;
	}

}
