﻿using UnityEngine;
using System.Collections;

public class Transformer : MonoBehaviour {

	public float Speed = 2f; // Meters per second
	public float RotationSpeed = 45f; // Degrees per second

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		// (Meters per second) * (Seconds in 1x frame) = (Meters in 1x frame)
		transform.Translate(Speed * Time.deltaTime, 0f, 0f);

		// (Degrees per second) * (Seconds in 1x frame) = (Degrees in 1x frame)
		transform.Rotate(RotationSpeed * Time.deltaTime, 0f, 0f);

		// If you rotate the cube along the y-axis, the direction its that its
		// x-axis points in will change. If you want to move the cube from left
		// to right while rotating along the y-axis, do this instead:
		// transform.Translate(Speed * Time.deltaTime, 0f, 0f, Space.World);
		// transform.Rotate(RotationSpeed * Time.deltaTime, 0f, 0f);
	}
}
