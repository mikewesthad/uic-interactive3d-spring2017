﻿using UnityEngine;
using System.Collections;

public class Staring : MonoBehaviour {

	public Transform playerTransform;

	// Use this for initializationjj
	void Start () {
		RandomizeTransform();
	}
	
	// Update is called once per frame
	void Update () {
		transform.LookAt(playerTransform);
		// Bonus: remove any rotation around the X/Z axes.
		transform.rotation = Quaternion.Euler(0, transform.eulerAngles.y, 0);
	}

	// Note: not part of the homework - just for fun
	void RandomizeTransform() {
		// Modify the X/Z position, but leave Y along so that the Pokemon
		// stays on the plane
		Vector3 position = transform.position;
		position.x = Random.Range(-10f, 10f);
		position.z = Random.Range(-10f, 10f);
		transform.position = position; // Leave this off for funky effects

		// Random scale
		float randomScale = Random.Range(0.5f, 1.5f);
		transform.localScale = Vector3.one * randomScale;

	}
}
