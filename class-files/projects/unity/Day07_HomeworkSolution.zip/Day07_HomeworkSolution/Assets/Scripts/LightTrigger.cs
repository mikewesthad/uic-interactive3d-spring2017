﻿using UnityEngine;
using System.Collections;

public class LightTrigger : MonoBehaviour {

	public Transform playerTrasform;
	public float triggerDistance = 15f;

	private Light light;

	// Use this for initialization
	void Start () {
		light = GetComponent<Light>();

		// For turning a light off/on, you can use intensity:
		//	LightComponent.intensity = 0f;
		// Or, you can leave the intensity alone and use the enabled property:
		light.enabled = false;
	}
	
	// Update is called once per frame
	void Update () {
		float distance = Vector3.Distance(transform.position, 
			playerTrasform.position);
		
		if (distance <= triggerDistance) {
			light.enabled = true;
		} else {
			light.enabled = false;
		}
	}
}
