                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:376601
Low-Poly Pikachu by FLOWALISTIK is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

I would love to keep sharing my projects with all the community. If you like my designs and want to support my work, now you can help with a donation.

http://bit.ly/2a7N4Et

---

NOTE: You can check my newest designs in my YouMagine profile! More Low-Poly and other simple designs!  

https://www.youmagine.com/users/flowalistik  

Designing a low-poly Pokemon is the best way I found to represent the poor graphic quality the first Pokemon games had. So, here I present you the low-poly Pikachu, which is part of the Low-Poly project I'm developing.   

3D printers allow to make real the idea of catching all Pokemon, and I'm currently working to make all the Pokemon I can. You can check the collection in the following page:   

http://www.thingiverse.com/FLOWALISTIK/collections/low-poly-pokemon   

This model is 5cm tall approximately. The model from the picture was printed with a Prusa i3, 0.2mm layer height, 0.5mm nozzle, 45mm/s speed and a cooling fan (I really recommend this!). The material is 3mm high quality PLA.   

It was designed so it doesn't need support material, although each printer is different and it may be more difficult to print it depending on the settings.   

// This design is based on Pokemon